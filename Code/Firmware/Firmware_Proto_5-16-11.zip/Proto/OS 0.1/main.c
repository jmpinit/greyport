#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

#include "Screen.h"
#include "Keyboard.h"
#include "Serial.h"
#include "Editor.h"

void bas_run(void);

typedef unsigned char boolean;
typedef unsigned char byte;

#define TRUE	0xFF
#define FALSE	0x00

#define CMD_SIZE 32

//commands
const char CMD_REBOOT[] PROGMEM = "reboot";
const char CMD_CLEAR[] PROGMEM = "clear";
const char CMD_RUN[] PROGMEM = "run";
const char CMD_EDITOR[] PROGMEM = "editor";

char command[CMD_SIZE];

void boot(void)
{
	//start the UART hardware
	uart_init(51);
	
	//start the LCD
	screen_initialize();
    screen_clear(0x00);
}

void get_command()
{
	boolean shift = FALSE;
	
	byte index = 0;
	char key = 0;
	while(key==0||key!=13)
	{
		key = key_get_key();
		
		if(key!=0&&index<CMD_SIZE)
		{
			if(key<=122&&key>=97)
			{
				if(shift)
				{
					command[index] = key-32;
				} else {
					command[index] = key;
				}
				
				screen_print_char(command[index]);
				index++;
			} else if(key==KEY_BACKSPACE)
			{
				if(index>0)
				{
					index--;
					command[index] = 0;
					screen_backspace();
					screen_print_char(' ');
					screen_backspace();
				}
			} else if(key==KEY_SHIFT)
			{
				if(shift)
				{
					shift = FALSE;
				} else {
					shift = TRUE;
				}
			} else if(key==KEY_CTRL)
			{
				//do nothing for now
			} else if(key==KEY_ALT)
			{
				//do nothing for now
			} else if(key!=13) {
				command[index] = key;
				screen_print_char(command[index]);
				index++;
			}
		}
	}
	
	screen_newline();
}

boolean str_cmp(char* str1, const char* str2)
{
	byte count = 0;
	char current;
	while((current=pgm_read_byte(str2)))
	{
		if(current!=*str1)
			return FALSE;
		
		str1++;
		str2++;
		
		count++;
	}
	
	return TRUE;
}

void parse_command()
{
	if(str_cmp(command, CMD_REBOOT))
	{
		boot();
	} else if(str_cmp(command, CMD_CLEAR))
	{
		screen_clear(0x00);
		screen_clear_shadow();
	} else if(str_cmp(command, CMD_RUN))
	{
		bas_run();
		screen_newline();
	} else if(str_cmp(command, CMD_EDITOR))
	{
		editor_run();
	} else {
		screen_print_string("bad command");
		screen_newline();
	}
	
	screen_print_char('>');
}

int main(void)
{
	boot();
	
	screen_print_char('>');
	
    for(;;)
    {
		get_command();
		parse_command();
    }
    
    // Never reached.
    return(0);
}