#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

#include "Editor.h"
#include "Screen.h"
#include "Keyboard.h"
#include "Serial.h"

const char TOK_NOP[] PROGMEM		= "NOP";

const char TOK_GOTO[] PROGMEM 		= "GOTO";
const char TOK_SET[] PROGMEM 		= "SET";

const char TOK_ADD[] PROGMEM 		= "ADD";
const char TOK_SUB[] PROGMEM 		= "SUB";
const char TOK_MULT[] PROGMEM 		= "MULT";
const char TOK_DIV[] PROGMEM 		= "DIV";

const char TOK_SKEQ[] PROGMEM 		= "SKEQ";
const char TOK_SKGR[] PROGMEM 		= "SKGR";
const char TOK_SKLT[] PROGMEM 		= "SKLT";
const char TOK_SKGREQ[] PROGMEM 	= "SKGREQ";
const char TOK_SKLTEQ[] PROGMEM 	= "SKLTEQ";

const char TOK_EXIT[] PROGMEM 		= "EXIT";

const char TOK_FUNCTION[] PROGMEM 	= "FUNC";

const char TOK_DELAY[] PROGMEM 		= "DELAY";
const char TOK_CLEAR[] PROGMEM 		= "CLEAR";
const char TOK_PRINT[] PROGMEM 		= "PRINT";

const char *TEXT_TABLE[] PROGMEM = {
	TOK_NOP,
	TOK_GOTO,
	TOK_SET,
	TOK_ADD,
	TOK_SUB,
	TOK_MULT,
	TOK_DIV,
	TOK_SKEQ,
	TOK_SKGR,
	TOK_SKLT,
	TOK_SKGREQ,
	TOK_SKLTEQ,
	TOK_EXIT,
	TOK_FUNCTION,
	TOK_DELAY,
	TOK_CLEAR,
	TOK_PRINT,
};

const unsigned char VAL_TABLE[] PROGMEM = {
	1,		//GOTO
	2,		//SET
	3,		//ADD
	4,		//SUB
	5,		//MULT
	6,		//DIV
	7,		//SKEQ
	8,		//SKGR
	9,		//SKLT
	10,		//SKGREQ
	11,		//SKLTEQ
	255,	//EXIT
	12,		//FUNCTION
	0,		//DELAY
	1,		//PRINT
	2		//CLEAR
};

unsigned char program[64];
int position;

void editor_run(void)
{
	//test by filling with every possible token in order
	for(int i=0; i<16; i++)
	{
		program[i] = i;
	}

	screen_clear(0x00);
	
	position = 0;
	
	render();
	
	while(1)
	{
		char key = key_get_key();
		
		if(key=='>'&&position<63)
		{
			position++;
			render();
		} else if(key=='<'&&position>0)
		{
			position--;
			render();
		}
	}
}

void render(void)
{
	screen_clear(0x00);
	for(unsigned int i=0; i<5; i++)
	{
		print_tok(program[position+i]);
		screen_newline();
	}
	print_tok(program[position+5]);
}

void print_tok(unsigned char token)
{
	int addr = 0;
	char c;
	while((c=pgm_read_byte(pgm_read_word(&TEXT_TABLE[token])+addr)))
	{
		screen_print_char(c);
		addr++;
	}
}