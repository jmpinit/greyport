//26 letter variables
//operator tokens
//function tokens

void editor_run(void);
void render(void);
void print_tok(unsigned char);