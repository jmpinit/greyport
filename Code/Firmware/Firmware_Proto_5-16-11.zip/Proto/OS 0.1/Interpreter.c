#include <avr/io.h>
#include <util/delay.h>

#include "Screen.h"
#include "Keyboard.h"
#include "Serial.h"

#define PROG_SIZE 64

//instruction defs
#define GOTO		1	//relative address (+/- 127)

#define SET			2	//var, 16 bit val

#define ADD			3	//var src1, var src2, var dest
#define SUB			4	//var src1, var src2, var dest
#define MULT		5	//var src1, var src2, var dest
#define DIV			6	//var src1, var src2, var dest

#define IF_EQ		7	//var src1, var src2
#define IF_GR		8	//var src1, var src2
#define IF_LESS		9	//var src1, var src2
#define IF_GREQ		10	//var src1, var src2
#define IF_LESSEQ	11	//var src1, var src2

#define FUNCTION	12	//function

#define EXIT		255

//function defs
#define DELAY		0
#define PRINT		1
#define CLEAR		2

unsigned char mem[] = { 2, 0, 0x01, 0xFF, 12, 1, 'h', 12, 0, 0, 12, 1, 'e', 12, 0, 0, 12, 1, 'l', 12, 0, 0, 12, 1, 'l', 12, 0, 0, 12, 1, 'o', 12, 0, 0 };
int variables[26];

void bas_run(void)
{
	int pc = 0;
	
	while(pc<PROG_SIZE)
	{
		unsigned char instruction = mem[pc];
		
		switch(instruction)
		{
			case GOTO:
				pc += (char)mem[pc+1];
				break;
				
			case SET:
				variables[mem[pc+1]] = (mem[pc+2]<<8)&mem[pc+3];
				pc += 4;
				break;
				
			case ADD:
				variables[mem[pc+1]] = variables[mem[pc+2]]+variables[mem[pc+3]];
				pc += 4;
				break;
				
			case SUB:
				variables[mem[pc+1]] = variables[mem[pc+2]]-variables[mem[pc+3]];
				pc += 4;
				break;
				
			case MULT:
				variables[mem[pc+1]] = variables[mem[pc+2]]*variables[mem[pc+3]];
				pc += 4;
				break;
				
			case DIV:
				variables[mem[pc+1]] = variables[mem[pc+2]]/variables[mem[pc+3]];
				pc += 4;
				break;
				
			case IF_EQ:
				if(variables[mem[pc+1]]==variables[mem[pc+2]])
				{
					pc += 4;
				} else {
					pc += 3;
				}
				break;
				
			case IF_GR:
				if(variables[mem[pc+1]]>variables[mem[pc+2]])
				{
					pc += 4;
				} else {
					pc += 3;
				}
				break;
			
			case IF_LESS:
				if(variables[mem[pc+1]]<variables[mem[pc+2]])
				{
					pc += 4;
				} else {
					pc += 3;
				}
				break;
				
			case IF_GREQ:
				if(variables[mem[pc+1]]>=variables[mem[pc+2]])
				{
					pc += 4;
				} else {
					pc += 3;
				}
				break;
				
			case IF_LESSEQ:
				if(variables[mem[pc+1]]<=variables[mem[pc+2]])
				{
					pc += 4;
				} else {
					pc += 3;
				}
				break;
				
			case EXIT:
				pc = PROG_SIZE;
				break;
				
			case FUNCTION:
				pc++;
				switch(mem[pc])
				{
					case DELAY:
						_delay_ms(variables[mem[pc+1]]);
						pc += 2;
						break;
						
					case PRINT:
						screen_print_char((char)mem[pc+1]);
						pc += 2;
						break;
						
					case CLEAR:
						screen_clear(0x00);
						pc++;
						break;
						
					default:
						pc++;
						break;
				}
				break;
				
			default:
				pc++;
				break;
		}
	}
}